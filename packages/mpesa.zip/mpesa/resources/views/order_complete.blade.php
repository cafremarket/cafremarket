@extends('theme::layouts.main')

@section('content')
  @include('theme::headers.order_detail')
  @include('theme::contents.order_complete')
  @include('theme::sections.recent_views')
@endsection

@section('scripts')
  @include('scripts.order_transaction_schema')
  <script>
  (function() {
    var statusUrl = '{{ url('mpesa/' . $order->id . '/status') }}';
    var completeUrl = '{{ url('mpesa/' . $order->id . '/complete') }}';
    var interval = setInterval(function() {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', statusUrl, true);
      xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
          try {
            var data = JSON.parse(xhr.responseText);
            if (data.paid) {
              clearInterval(interval);
              window.location.href = completeUrl;
            }
          } catch (e) {}
        }
      };
      xhr.send();
    }, 3000);
  })();
  </script>
@endsection
