<?php

namespace Incevio\Package\LiveChat\Http\Requests;

use App\Http\Requests\Request;

class ViewChatConversationRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        if ($this->user() && ($this->user()->merchantId() == $this->chat->shop_id)) {
            return true;
        }

        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }
}
