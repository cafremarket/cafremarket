<?php

namespace App\Events\Order;

use App\Models\Order;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class OrderCancelled
{
    use Dispatchable, SerializesModels;

    public $order;

    public $notify_customer;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Order $order, $notify_customer = true)
    {
        $this->order = $order;
        $this->notify_customer = $notify_customer;
    }
}
