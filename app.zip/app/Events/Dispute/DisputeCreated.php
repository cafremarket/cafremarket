<?php

namespace App\Events\Dispute;

use App\Models\Dispute;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class DisputeCreated
{
    use Dispatchable, SerializesModels;

    public $dispute;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Dispute $dispute)
    {
        $this->dispute = $dispute;
    }
}
